
const weddingDate = new Date('August 15, 2025 16:00:00').getTime();

function updateCountdown() {
    const now = new Date().getTime();
    const distance = weddingDate - now;

    if (distance <= 0) {
        document.getElementById('countdown-timer').innerHTML = "🎉 Свадьба началась! 🎉";
        return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    document.getElementById('countdown-timer').innerHTML = 
        `${days} дней ${hours} часов ${minutes} минут ${seconds} секунд`;
}

setInterval(updateCountdown, 1000);
updateCountdown();
